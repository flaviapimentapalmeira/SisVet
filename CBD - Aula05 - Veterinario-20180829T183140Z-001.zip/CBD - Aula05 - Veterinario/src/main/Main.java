/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import animal_dao.Animal_Dao;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Model_animal;

/**
 *
 * @author Aluno
 */
public class Main {
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        String nome= "Meg";
        
        ArrayList<Model_animal> lista2 = new ArrayList<Model_animal>();
        Animal_Dao ad1 = new Animal_Dao();
        lista2 = ad1.consultarAnimalPeloNome(nome);
        
        for (int i = 0; i < lista2.size(); i++) {
            Model_animal a2 = new Model_animal();
            a2 = lista2.get(i);
            System.out.println("Id: "+a2.getId_animal());
            System.out.println("Nome: "+a2.getNome_animal());
            System.out.println("Raça: "+a2.getRaca_animal());
            System.out.println("Idade: "+a2.getIdade_animal());
            System.out.println("\n");
            
        }
    }
}
