/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animal_dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Model_animal;

/**
 *
 * @author Aluno
 */
public class Animal_Dao {
    
    private final String SHEMA = "veterinario";
    private final String CAMINHO = "jdbc:mysql://localhost/"+SHEMA;
    private final String USUARIO_BD = "root";
    private final String SENHA_BD = "bancodedados";
    
    //QUERY'S
    private final String CONSULTAR_ANIMAL_PELO_NOME = "SELECT * FROM cadastrar_animal WHERE nome_animal = (?)";
    
    // CONEXAO COM BD
    private static Connection connection = null;
    private static PreparedStatement stmt = null;
    private static ResultSet resultset = null;
    
    // CONSTRUTOR Alt+INSERT

    public Animal_Dao() throws ClassNotFoundException {
        // registrar o driver JDBC
        Class.forName ("com.mysql.jdbc.Driver");
    }

    //Consultar retornando uma lista
    public ArrayList<Model_animal> consultarAnimalPeloNome(String nome) throws SQLException {
        
        //conexão com o banco de dados======
        connection = DriverManager.getConnection(CAMINHO, USUARIO_BD, SENHA_BD);
        System.out.println("Conectou ao banco!!!!");
        //==============================
        
        //Preparar a Query===========
        String query = CONSULTAR_ANIMAL_PELO_NOME ;
        stmt = connection.prepareStatement(query);
        stmt.setString(1, nome);
        
        //execulta a query
        ArrayList<Model_animal> lista1 = new ArrayList<Model_animal>();
        resultset = stmt.executeQuery();
        
        //Animal a1 = new Animal();
        
        while (resultset.next()){
            Model_animal a1 = new Model_animal();
            //Carregando o objeto
            a1.setId_animal(resultset.getInt(1));
            a1.setNome_animal(resultset.getString(2));
            a1.setRaca_animal(resultset.getString(3));
            a1.setIdade_animal(resultset.getInt(4));
            
            //adicionar na lista
            
            lista1.add(a1);
        }
                   
        //fechar conexao
        stmt.close();
        resultset.close();
        connection.close();
        System.out.println("Fechou Conexão");       
       
        return lista1;
    }

    public void consulta(int idade) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
    
    
    

